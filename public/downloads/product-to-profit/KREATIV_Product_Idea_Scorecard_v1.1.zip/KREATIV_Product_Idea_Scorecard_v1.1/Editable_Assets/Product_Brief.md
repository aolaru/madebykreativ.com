# Product Brief

This is the required handoff from **Product Idea Scorecard** to **Workflow Product Builder**. Use exact buyer evidence where available. Do not invent proof to complete a field.

| Field ID | Field | Answer | Evidence or source |
| --- | --- | --- | --- |
| PB-01 | Working title |  |  |
| PB-02 | Specific buyer |  |  |
| PB-03 | Triggering situation |  |  |
| PB-04 | Core problem |  |  |
| PB-05 | Current workaround |  |  |
| PB-06 | Desired progress |  |  |
| PB-07 | Chosen format |  |  |
| PB-08 | One-sentence promise |  |  |
| PB-09 | Version 1 boundary |  |  |
| PB-10 | Current evidence |  |  |
| PB-11 | Useful difference (optional) |  |  |
| PB-12 | Biggest risk |  |  |
| PB-13 | Next evidence test |  |  |
| PB-14 | Continue signal |  |  |
| PB-15 | Stop or change signal |  |  |
| PB-16 | Decision: Continue, Narrow, Reposition, or Stop |  |  |
| PB-17 | Decision date |  |  |

## Builder Intake Gate

- [ ] All required fields contain specific answers.
- [ ] At least one evidence test was completed with the intended buyer.
- [ ] The decision is Continue, Narrow, or Reposition.
- [ ] The version 1 boundary can be built without adding unrelated features.

Gate result: **READY FOR BUILDER / NOT READY**
