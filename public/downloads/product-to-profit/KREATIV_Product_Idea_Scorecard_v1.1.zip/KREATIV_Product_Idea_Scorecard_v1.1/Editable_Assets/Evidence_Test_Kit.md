# Evidence Test Kit

Use one test to reduce the biggest uncertainty in the Product Brief. Record observed behavior and exact words separately from your interpretation.

## Select the test

| Uncertainty | Best first test | Stronger signal |
| --- | --- | --- |
| Buyer or problem is unclear | Five short interviews | Repeated problem language and recent examples |
| Promise is unclear | Two-message preview test | Qualified replies asking for access or details |
| Format is unclear | Clickable or sample preview | Buyer completes a realistic task unaided |
| Willingness to pay is unclear | Preorder or paid pilot | Payment from an intended buyer |
| Scope is unclear | Concierge delivery | Repeated steps reveal the minimum workflow |

## Buyer interview script

Opening: “I am researching how [buyer type] handles [situation]. I am not selling anything in this conversation. Could I ask about the last time this happened?”

1. What triggered the work?
2. What did you do first, then next?
3. Where did the process slow down or become uncertain?
4. What did you use instead?
5. What did the workaround cost in time, money, risk, or missed progress?
6. What would a useful result look like?
7. Have you paid for help, a tool, or a template for this before?
8. What would make a new solution untrustworthy or not worth changing for?

Do not ask “Would you buy this?” Describe a concrete preview only after the behavior questions.

## Preview feedback request

Subject: Quick reality check on [specific workflow]

“I made a rough [format] for [specific buyer] who needs to [progress] when [trigger]. It includes [three concrete contents]. Could you use this preview for one realistic example and tell me where you hesitate, what is missing, and what you would ignore? I am looking for usability evidence, not compliments.”

## Waitlist test

- Publish one promise, three concrete contents, intended buyer, expected delivery date, and one CTA.
- Count qualified visits, sign-ups, replies, and objections separately.
- Define the continue threshold before publishing.
- Do not treat likes or broad traffic as demand evidence.

## Preorder or paid-pilot checklist

- [ ] Buyer, outcome, format, delivery date, and beta status are explicit.
- [ ] Buyer sees exactly what exists now and what will be delivered later.
- [ ] Refund and cancellation terms are written before payment.
- [ ] Capacity and support boundary are realistic.
- [ ] Payments, refunds, and non-buying objections are recorded.

## Evidence log

| Date | Test | Intended buyer? | Observation or exact words | Signal strength (1-5) | Implication | Product Brief field affected | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |

## Decision rule

Choose **Continue** when intended buyers show the problem and take the predefined action. Choose **Narrow** when the signal is concentrated in a smaller buyer or situation. Choose **Reposition** when the problem is real but the promise or format misses. Choose **Stop** when repeated tests fail the threshold or reveal a low-cost workaround that is already sufficient.
