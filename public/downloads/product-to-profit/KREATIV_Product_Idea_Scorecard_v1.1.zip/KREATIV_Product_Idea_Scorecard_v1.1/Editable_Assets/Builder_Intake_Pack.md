# Builder Intake Pack

Attach this page to the completed Product Brief.

## Decision summary

- Selected idea:
- Decision: Continue / Narrow / Reposition
- Evidence test completed:
- Number of intended buyers exposed to the test:
- Strongest observed behavior:
- Strongest exact objection:
- Biggest unresolved risk:

## Version 1 contract

- Buyer:
- Trigger:
- Supported progress:
- Chosen format:
- Must include:
- Explicitly excludes:
- Definition of useful:
- Build deadline:

## Source material available

- Existing expertise, process, or examples:
- Buyer language or interview notes:
- Reference tools or constraints:
- Claims that require verification:
- Privacy, copyright, or disclosure constraints:

## Handoff check

- [ ] The Product Brief uses the PB-01 to PB-17 fields.
- [ ] Evidence is linked or attached.
- [ ] The Builder can start without choosing a different audience or problem.
