# KREATIV Idea Library - Stage 0 Boundary

## Job

Generate and compare plausible product directions. The finish line is a shortlist of no more than three ideas, ready for the Product Idea Scorecard.

## Use this product for

- recognizing product patterns;
- translating skills and recurring problems into possible products;
- creating an initial list without committing to a build;
- selecting three candidates for evidence-based scoring.

## Do not use this product for

- validating demand;
- choosing final pricing;
- building files;
- writing a sales page;
- planning a launch.

Those decisions belong to the Scorecard, Builder, and Launch Engine. Any pricing or promotion examples in the original PDF are orientation only, not recommendations.

## Exit artifact: Idea Shortlist

Complete one row for each of up to three ideas.

| Field ID | Field | Idea 1 | Idea 2 | Idea 3 |
| --- | --- | --- | --- | --- |
| IS-01 | Working name |  |  |  |
| IS-02 | Specific buyer |  |  |  |
| IS-03 | Triggering situation |  |  |  |
| IS-04 | Painful workflow |  |  |  |
| IS-05 | Desired progress |  |  |  |
| IS-06 | Possible format |  |  |  |
| IS-07 | Evidence already available |  |  |  |
| IS-08 | Fastest evidence test |  |  |  |
| IS-09 | Why you can credibly help |  |  |  |

Move all three candidates into the **Idea Shortlist** sheet in the master workspace. The Product Idea Scorecard decides which one deserves a test.
