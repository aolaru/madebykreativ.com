# Start Here - KREATIV Product Idea Scorecard

Use this package to compare possible digital products and finish with one evidence-backed Product Brief.

## Start in three steps

1. Save a working copy of `KREATIV_Product_Idea_Scorecard_v1.3.pdf` before filling it.
2. Choose the Full Path or Fast Path below.
3. Complete one small evidence test before moving to Workflow Product Builder.

## Choose your path

**Full Path:** Complete all workbook pages in order when your audience, problem, or initial ideas are still unclear.

**Fast Path:** Complete pages 7-10 and 21-33, including the three scorecards on pages 24-26 before comparing the results on page 27. Use the product blueprints and worked examples when you need help.

## Finish line

Your final output is a Product Brief containing:

- one specific buyer and triggering situation;
- one meaningful problem and current workaround;
- the smallest useful format and a realistic promise;
- current evidence and the biggest unresolved risk;
- one completed evidence test and its result;
- a Continue, Narrow, Reposition, Retest, or Stop decision.

## Package guide

- `KREATIV_Product_Idea_Scorecard_v1.3.pdf`: primary interactive workbook, with all canonical Brief fields on pages 31-32.
- `Editable_Assets/Product_Brief.md`: portable handoff to Workflow Product Builder.
- `Editable_Assets/Evidence_Test_Kit.md`: interview, preview, waitlist, preorder, and concierge test methods.
- `Editable_Assets/Evidence_Log.csv`: structured evidence record.
- `Editable_Assets/Builder_Intake_Pack.md`: final readiness check for Stage 2.
- `Editable_Assets/Advanced_Choose_Prompt_Expansion_v1.0.*`: optional AI-assisted analysis prompts.

Do not treat scores, AI output, compliments, or broad traffic as proof of demand. Record observed behavior separately from assumptions.
