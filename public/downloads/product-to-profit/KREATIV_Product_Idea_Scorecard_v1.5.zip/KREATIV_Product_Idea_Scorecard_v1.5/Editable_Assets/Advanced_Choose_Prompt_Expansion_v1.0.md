# KREATIV Product Idea Scorecard - Advanced Choose Prompt Expansion

These prompts migrate relevant material from the retired Money-Making AI Prompts Toolkit. They extend the stage without changing its required input, output, or evidence gate.

## Stage rule

Use the approved stage artifact as context. AI drafts do not replace buyer evidence, human review, current-fact verification, or the stage decision.

### DP-01: Find Product Ideas

**Source:** retired toolkit v1.1, page 16

```text
Generate 20 digital product ideas I can create in under 7 days. Organize them by buyer, triggering situation, painful workflow, proposed format, and the smallest evidence test. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

### DP-02: Validate Before Building

**Source:** retired toolkit v1.1, page 16

```text
Analyze this digital product idea: [idea]. Separate known evidence from assumptions. Identify the specific buyer, triggering situation, current workaround, desired progress, major risk, smallest MVP, and next observable evidence test. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

### SAAS-01: Generate Micro-SaaS Hypotheses

**Source:** retired toolkit v1.1, page 19

```text
Generate twenty Micro-SaaS hypotheses for [buyer or workflow]. For each, name the painful repeated task, current workaround, proposed recurring value, smallest test, and evidence still missing. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

### SAAS-02: Validate a SaaS Hypothesis

**Source:** retired toolkit v1.1, page 19

```text
Audit [SaaS idea] using supplied evidence. Separate buyer urgency, current workaround, competition, willingness-to-pay evidence, differentiation, and riskiest assumption. Design a pre-build test. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

### NEWS-01: Newsletter Niches

**Source:** retired toolkit v1.1, page 21

```text
Generate fifteen newsletter hypotheses from [skills, audience access, and topics]. For each, define reader job, recurring information need, existing alternatives, source burden, and smallest subscription test. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

### AFF-01: Affiliate Niche Hypotheses

**Source:** retired toolkit v1.1, page 23

```text
Generate twenty affiliate-content hypotheses from [expertise and audience]. For each, define buyer decision, product category, disclosure burden, source requirements, content moat, and evidence to verify commercial viability. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

### MP-001: Role-Setting and Validation

**Source:** retired toolkit v1.1, page 26

```text
Act as a venture analyst. Generate 10 micro-niche markets that meet these criteria: annual search demand, existing low-quality solutions, clear monetization path. Present a table with niche, core problem, current solution rating, and suggested product. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-002: Market Change Analysis

**Source:** retired toolkit v1.1, page 26

```text
Generate 5 supported by demand signals to verify digital product trends from the last 6 months. For each trend, identify the underlying user pain point and suggest a counter-product that is meaningfully differentiated than current market leaders. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-003: Skills-to-Product Architecture

**Source:** retired toolkit v1.1, page 26

```text
Turn these skills into 5 specific high-ticket digital product offers: [skills]. For each offer, define ideal buyer, transformation, deliverables, and launch date. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-004: Resilient Need Hypotheses

**Source:** retired toolkit v1.1, page 26

```text
Give me 10 commercially plausible resilience-oriented business ideas focused on cost saving or income generation. Define target persona, primary fear, and product angle. Treat all monetary values as hypotheses or user-defined scenarios, not promised outcomes. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-005: Problem-to-Solution Mapping

**Source:** retired toolkit v1.1, page 26

```text
Find 10 problems people discuss on [platform] around [topic]. Map each problem to a unique digital solution I can build in 48 hours. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-006: Subscription Model Innovation

**Source:** retired toolkit v1.1, page 26

```text
Give me 10 subscription-friendly Micro-SaaS ideas. Define the MVP and recurring value hook that justifies a $9/month price. Treat all monetary values as hypotheses or user-defined scenarios, not promised outcomes. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-007: High-Leverage Tool Concepts

**Source:** retired toolkit v1.1, page 27

```text
List 10 tools people in [niche] may consider paying for. Define core functionality, name, and meaningful benefit hypothesis over manual work. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-008: Buyer Access Hypotheses

**Source:** retired toolkit v1.1, page 27

```text
Identify 5 niche audiences I can build and monetize. For each, define primary channel and first product to sell. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-009: General Idea

**Source:** retired toolkit v1.1, page 27

```text
Give me 20 commercially plausible online business ideas based on my skills: [skills]. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-010: Hidden Niches

**Source:** retired toolkit v1.1, page 27

```text
Find hidden niche markets people are spending money in right now. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-011: Low-Cost Startup

**Source:** retired toolkit v1.1, page 27

```text
Generate business ideas with low startup cost and high upside. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-012: Current Demand Signals

**Source:** retired toolkit v1.1, page 27

```text
List digital products currently trending on creator marketplaces and explain why buyers want them. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-013: Quick Build

**Source:** retired toolkit v1.1, page 27

```text
Give me 10 business ideas I can build in 7 days. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-014: Demand / Poor Solutions

**Source:** retired toolkit v1.1, page 27

```text
Find niches with demand but poor existing solutions. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

### MP-015: Current Business Signals

**Source:** retired toolkit v1.1, page 27

```text
Give me 10 business trends I should build for this year. Use dated primary sources for any current market or platform claim and mark unknowns. Separate supplied facts, assumptions, and recommendations. Do not invent demand, proof, testimonials, or results.
```

**Evidence check:** Verify with buyer behavior, current alternatives, and a predefined evidence test.

